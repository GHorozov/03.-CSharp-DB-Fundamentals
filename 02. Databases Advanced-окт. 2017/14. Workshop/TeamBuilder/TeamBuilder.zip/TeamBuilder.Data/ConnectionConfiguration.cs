﻿namespace TeamBuilder.Data
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    
    public class ConnectionConfiguration
    {
        public static string ConnectionString = "Server=DESKTOP-QIOC91F\\SQLEXPRESS;Database=TeamBuilder;Integrated Security=True;";
    }
}