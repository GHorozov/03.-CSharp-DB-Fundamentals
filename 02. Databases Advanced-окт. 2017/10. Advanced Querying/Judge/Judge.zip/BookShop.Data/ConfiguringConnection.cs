﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BookShop.Data
{
    class ConfiguringConnection
    {
        public const string ConsigurationString = "Server=DESKTOP-QIOC91F\\SQLEXPRESS;Database=BookShop;Integrated Security=True;";
    }
}
