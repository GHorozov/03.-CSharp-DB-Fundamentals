﻿namespace Stations.DataProcessor.Dto
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    
    public class StationDto
    {
        public string Name { get; set; }
        public string Town { get; set; }
    }
}