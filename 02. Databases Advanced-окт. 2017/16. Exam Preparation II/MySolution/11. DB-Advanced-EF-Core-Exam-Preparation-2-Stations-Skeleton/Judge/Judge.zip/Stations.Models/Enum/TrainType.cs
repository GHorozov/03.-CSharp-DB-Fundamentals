﻿namespace Stations.Models.Enum
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    
    public enum TrainType
    {
        HighSpeed,
        LongDistance,
        Freight
    }
}