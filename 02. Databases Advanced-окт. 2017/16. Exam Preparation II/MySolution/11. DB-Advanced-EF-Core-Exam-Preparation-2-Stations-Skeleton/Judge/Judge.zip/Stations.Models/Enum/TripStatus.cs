﻿namespace Stations.Models.Enum
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    
    public enum TripStatus
    {
        OnTime,
        Delayed,
        Early
    }
}