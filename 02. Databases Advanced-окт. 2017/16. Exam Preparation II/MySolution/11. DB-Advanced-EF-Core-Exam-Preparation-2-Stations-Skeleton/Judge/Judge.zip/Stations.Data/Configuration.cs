namespace Stations.Data
{
	public static class Configuration
	{
		public static string ConnectionString = @"Server=DESKTOP-QIOC91F\SQLEXPRESS;Database=Stations;Integrated Security=True";
	}
}