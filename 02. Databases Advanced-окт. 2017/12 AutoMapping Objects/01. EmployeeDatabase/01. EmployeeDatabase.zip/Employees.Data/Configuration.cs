﻿namespace Employees.Data
{
    public static class Configuration
    {
        public static string ConnectionString => "Server=DESKTOP-QIOC91F\\SQLEXPRESS;Database=EmployeeDatabase;Integrated Security = True;";
    }
}
