﻿namespace P01_BillsPaymentSystem.Data
{
    public static class Configuration
    {
        public const string ConfigurationString = "Server=DESKTOP-QIOC91F\\SQLEXPRESS;Database=BillsPaymentSystem;Integrated Security=True";
    }
}
