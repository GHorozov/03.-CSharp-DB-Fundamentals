﻿namespace P01_StudentSystem.Data.Models.Configurations
{
    public static class DBContextConfiguration
    {
        public const string ConfigurationString = "Server=DESKTOP-QIOC91F\\SQLEXPRESS;Database=StudentSystem;Integrated Security=True;";
    }
}
