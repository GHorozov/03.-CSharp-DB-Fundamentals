﻿namespace P03_FootballBetting.Data
{
    public static class ConfugureConnection
    {
        public const string ConnectionString = "Server=DESKTOP-QIOC91F\\SQLEXPRESS;Database=FootballBettingSystem;Integrated Security=True;";
    }
}
